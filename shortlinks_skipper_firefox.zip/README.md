# Shortlinks Skipper

A cross-browser Manifest V3 extension that automatically skips common shortlink pages (WP Safelink, ouo.io, linkvertise-style, generic redirect pages) and redirects immediately to the final destination.

## Features
- Auto-detects and clicks through common shortlink flows
- Auto-redirects immediately to final destination when possible
- Cross-browser (Chrome, Edge, Firefox MV3)
- Whitelist and blacklist domains (via popup)
- Enable/disable toggle
- Safe, runs only when relevant elements are detected

## Installation (Load Unpacked)
1. Clone/download this repo
2. Open browser extensions page:
   - Chrome: chrome://extensions/
   - Edge: edge://extensions/
   - Firefox: about:debugging#/runtime/this-firefox → Load Temporary Add-on
3. Enable "Developer mode"
4. Click "Load unpacked" and select the `shortlinks_skipper` folder
5. Pin the extension if desired

## Usage
Click the extension icon to open popup:
- Toggle "Enabled" on/off
- Whitelist: if non-empty, extension only runs on listed domains (and subdomains)
- Blacklist: extension never runs on listed domains (takes precedence)

## Supported Patterns (initial)
- WP Safelink (wpsafelinkhuman, wpsafe-generate, wpsafe-link with window.open)
- ouo.io / ouo.press
- Generic skip buttons (#skip_button, .skip)
- Linkvertise-like elements
- Common final download/redirect links

## Notes
- Uses MutationObserver to handle dynamically loaded steps
- Marks pages as processed to avoid loops
- May not work on some sites with heavy anti-bot or captcha flows

## Development
Files: manifest.json, content.js, background.js, popup.html, popup.js, icons/
